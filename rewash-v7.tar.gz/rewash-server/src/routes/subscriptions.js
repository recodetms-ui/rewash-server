// src/routes/subscriptions.js — اشتراكات المالكين + عضويات الزباين
'use strict';
const express = require('express');
const { query } = require('../db/pool');
const { adminAuth, ownerAuth } = require('../middleware/auth');

const router = express.Router();

// ═══════════ اشتراكات المالكين بالنظام (المطوّر) ═══════════

// قائمة كل الاشتراكات + حالة كل مالك (آخر اشتراك)
router.get('/admin/subscriptions', adminAuth, async (req, res) => {
  try {
    const r = await query(`
      SELECT s.id, s.owner_id, o.name AS owner_name, o.phone,
        s.plan, s.amount_iqd, s.start_date, s.end_date, s.note,
        (s.end_date >= CURRENT_DATE) AS active,
        (s.end_date - CURRENT_DATE) AS days_left
      FROM owner_subscriptions s
      JOIN owners o ON o.id = s.owner_id
      ORDER BY s.end_date DESC, s.id DESC LIMIT 300`);
    // ملخّص: مالكون بلا اشتراك فعّال
    const summary = await query(`
      SELECT
        (SELECT COUNT(*) FROM owners) AS total_owners,
        (SELECT COUNT(DISTINCT owner_id) FROM owner_subscriptions WHERE end_date >= CURRENT_DATE) AS active_owners,
        (SELECT COALESCE(SUM(amount_iqd),0) FROM owner_subscriptions
          WHERE start_date > now() - interval '30 days') AS revenue_30d`);
    res.json({ ok: true, subscriptions: r.rows, summary: summary.rows[0] });
  } catch (e) { console.error('[admin subs]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});

// إضافة/تجديد اشتراك مالك
router.post('/admin/subscriptions', adminAuth, async (req, res) => {
  try {
    const { owner_id, plan, amount_iqd, start_date, months, note } = req.body || {};
    if (!owner_id) return res.status(400).json({ error: 'اختر مالكاً' });
    const m = parseInt(months, 10) || 1;
    const start = start_date || null;
    const r = await query(`
      INSERT INTO owner_subscriptions (owner_id, plan, amount_iqd, start_date, end_date, note)
      VALUES ($1, $2, $3, COALESCE($4::date, CURRENT_DATE),
        COALESCE($4::date, CURRENT_DATE) + ($5 || ' months')::interval, $6)
      RETURNING id, end_date`,
      [owner_id, (plan || 'شهري').trim(), parseInt(amount_iqd, 10) || 0, start, String(m), (note || '').trim() || null]);
    res.json({ ok: true, id: r.rows[0].id, end_date: r.rows[0].end_date });
  } catch (e) { console.error('[add sub]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});

// حذف اشتراك
router.delete('/admin/subscriptions/:id', adminAuth, async (req, res) => {
  try {
    const r = await query('DELETE FROM owner_subscriptions WHERE id = $1 RETURNING id', [req.params.id]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// المالك يشوف حالة اشتراكه بالنظام
router.get('/my/subscription', ownerAuth, async (req, res) => {
  try {
    const r = await query(`
      SELECT plan, amount_iqd, start_date, end_date,
        (end_date >= CURRENT_DATE) AS active,
        (end_date - CURRENT_DATE) AS days_left
      FROM owner_subscriptions WHERE owner_id = $1
      ORDER BY end_date DESC LIMIT 1`, [req.owner.id]);
    res.json({ ok: true, subscription: r.rows[0] || null });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══════════ عضويات زباين المغسلة (المالك) ═══════════

router.get('/my/memberships', ownerAuth, async (req, res) => {
  try {
    const q = (req.query.q || '').trim();
    const params = [req.owner.id];
    let where = 'WHERE m.owner_id = $1';
    if (q) { params.push('%' + q + '%'); where += ' AND (m.customer_name ILIKE $2 OR m.customer_phone ILIKE $2)'; }
    const r = await query(`
      SELECT m.id, m.customer_name, m.customer_phone, m.plan, m.price_iqd,
        m.washes_total, m.washes_used, m.start_date, m.end_date, m.note,
        b.name AS branch_name,
        (m.end_date IS NULL OR m.end_date >= CURRENT_DATE) AS active
      FROM customer_memberships m
      LEFT JOIN branches b ON b.id = m.branch_id
      ${where}
      ORDER BY m.id DESC LIMIT 300`, params);
    res.json({ ok: true, memberships: r.rows });
  } catch (e) { console.error('[my mem]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});

router.post('/my/memberships', ownerAuth, async (req, res) => {
  try {
    const { customer_name, customer_phone, plan, price_iqd, washes_total, months, branch_id, note } = req.body || {};
    if (!customer_name || !customer_name.trim()) return res.status(400).json({ error: 'أدخل اسم الزبون' });
    const m = parseInt(months, 10) || 1;
    const r = await query(`
      INSERT INTO customer_memberships
        (owner_id, branch_id, customer_name, customer_phone, plan, price_iqd, washes_total, start_date, end_date, note)
      VALUES ($1,$2,$3,$4,$5,$6,$7, CURRENT_DATE, CURRENT_DATE + ($8 || ' months')::interval, $9)
      RETURNING id`,
      [req.owner.id, branch_id || null, customer_name.trim(), (customer_phone || '').trim() || null,
       (plan || 'شهري').trim(), parseInt(price_iqd, 10) || 0, parseInt(washes_total, 10) || 0, String(m), (note || '').trim() || null]);
    res.json({ ok: true, id: r.rows[0].id });
  } catch (e) { console.error('[add mem]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});

// تسجيل استخدام غسلة (washes_used++)
router.post('/my/memberships/:id/use', ownerAuth, async (req, res) => {
  try {
    const r = await query(`
      UPDATE customer_memberships SET washes_used = washes_used + 1
      WHERE id = $1 AND owner_id = $2
      RETURNING washes_used, washes_total`, [req.params.id, req.owner.id]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true, ...r.rows[0] });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

router.delete('/my/memberships/:id', ownerAuth, async (req, res) => {
  try {
    const r = await query('DELETE FROM customer_memberships WHERE id = $1 AND owner_id = $2 RETURNING id',
      [req.params.id, req.owner.id]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

module.exports = router;
