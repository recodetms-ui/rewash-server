-- 005_batchB.sql — لقطات النسخ الاحتياطي التلقائي المجدول
CREATE TABLE IF NOT EXISTS auto_backups (
  id          BIGSERIAL PRIMARY KEY,
  label       TEXT NOT NULL DEFAULT 'تلقائي',
  size_bytes  BIGINT NOT NULL DEFAULT 0,
  counts      JSONB,                 -- عدد السجلات لكل جدول (للعرض السريع)
  data        JSONB NOT NULL,        -- نسخة كاملة من البيانات
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_auto_backups_created ON auto_backups(created_at DESC);

-- إعدادات النظام (مفتاح/قيمة) — لتخزين توكن واتساب وغيره
CREATE TABLE IF NOT EXISTS app_settings (
  key        TEXT PRIMARY KEY,
  value      TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
