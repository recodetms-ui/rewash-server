-- 004_batch5.sql — موظفون + خدمات + بيانات المحل (إدخال من لوحة المالك)

CREATE TABLE IF NOT EXISTS employees (
  id          BIGSERIAL PRIMARY KEY,
  owner_id    BIGINT NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
  branch_id   BIGINT REFERENCES branches(id) ON DELETE SET NULL,
  name        TEXT NOT NULL,
  role        TEXT DEFAULT 'موظف',
  phone       TEXT,
  salary_iqd  BIGINT NOT NULL DEFAULT 0,
  active      BOOLEAN NOT NULL DEFAULT true,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_employees_owner ON employees(owner_id);

CREATE TABLE IF NOT EXISTS services (
  id           BIGSERIAL PRIMARY KEY,
  owner_id     BIGINT NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
  branch_id    BIGINT REFERENCES branches(id) ON DELETE SET NULL,
  name         TEXT NOT NULL,
  price_iqd    BIGINT NOT NULL DEFAULT 0,
  duration_min INTEGER NOT NULL DEFAULT 15,
  active       BOOLEAN NOT NULL DEFAULT true,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_services_owner ON services(owner_id);

-- بيانات المحل على سجل المالك (PG16 يدعم ADD COLUMN IF NOT EXISTS)
ALTER TABLE owners ADD COLUMN IF NOT EXISTS store_name TEXT;
ALTER TABLE owners ADD COLUMN IF NOT EXISTS address TEXT;
ALTER TABLE owners ADD COLUMN IF NOT EXISTS notes TEXT;
