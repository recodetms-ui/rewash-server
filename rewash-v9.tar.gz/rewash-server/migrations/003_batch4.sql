-- 003_batch4.sql — اشتراكات المالكين بالنظام + عضويات زباين المغسلة

-- اشتراك المالك بالنظام (يديره المطوّر): مين دفع ومتى ينتهي
CREATE TABLE IF NOT EXISTS owner_subscriptions (
  id          BIGSERIAL PRIMARY KEY,
  owner_id    BIGINT NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
  plan        TEXT NOT NULL DEFAULT 'شهري',
  amount_iqd  BIGINT NOT NULL DEFAULT 0,
  start_date  DATE NOT NULL DEFAULT CURRENT_DATE,
  end_date    DATE NOT NULL,
  note        TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_owner_subs_owner ON owner_subscriptions(owner_id);
CREATE INDEX IF NOT EXISTS idx_owner_subs_end ON owner_subscriptions(end_date);

-- عضوية زبون المغسلة (يديرها المالك): اشتراك شهري/باقة غسلات
CREATE TABLE IF NOT EXISTS customer_memberships (
  id            BIGSERIAL PRIMARY KEY,
  owner_id      BIGINT NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
  branch_id     BIGINT REFERENCES branches(id) ON DELETE SET NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT,
  plan          TEXT NOT NULL DEFAULT 'شهري',
  price_iqd     BIGINT NOT NULL DEFAULT 0,
  washes_total  INTEGER NOT NULL DEFAULT 0,   -- 0 = غير محدودة
  washes_used   INTEGER NOT NULL DEFAULT 0,
  start_date    DATE NOT NULL DEFAULT CURRENT_DATE,
  end_date      DATE,
  note          TEXT,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_cust_mem_owner ON customer_memberships(owner_id);
CREATE INDEX IF NOT EXISTS idx_cust_mem_phone ON customer_memberships(customer_phone);
