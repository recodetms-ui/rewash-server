// src/routes/owner-manage.js — إدارة المالك لفروعه وموظفيه وخدماته وبيانات محله
'use strict';
const express = require('express');
const { query } = require('../db/pool');
const { ownerAuth } = require('../middleware/auth');

const router = express.Router();

// ═══════════ بيانات المحل (بروفايل المالك) ═══════════
router.get('/my/profile', ownerAuth, async (req, res) => {
  try {
    const r = await query('SELECT id, name, phone, store_name, address, notes FROM owners WHERE id = $1', [req.owner.id]);
    res.json({ ok: true, profile: r.rows[0] || null });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});
router.patch('/my/profile', ownerAuth, async (req, res) => {
  try {
    const { store_name, address, notes } = req.body || {};
    const r = await query(
      `UPDATE owners SET store_name = $2, address = $3, notes = $4 WHERE id = $1
       RETURNING store_name, address, notes`,
      [req.owner.id, (store_name || '').trim() || null, (address || '').trim() || null, (notes || '').trim() || null]);
    res.json({ ok: true, profile: r.rows[0] });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══════════ فروع المالك (إدارة ذاتية) ═══════════
router.post('/my/branches', ownerAuth, async (req, res) => {
  try {
    const { name, city } = req.body || {};
    if (!name || !name.trim()) return res.status(400).json({ error: 'أدخل اسم الفرع' });
    const r = await query(
      `INSERT INTO branches (owner_id, name, city) VALUES ($1, $2, $3) RETURNING id, name, city`,
      [req.owner.id, name.trim(), (city || '').trim() || null]);
    res.json({ ok: true, branch: r.rows[0] });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});
router.patch('/my/branches/:id', ownerAuth, async (req, res) => {
  try {
    const { name, city } = req.body || {};
    const r = await query(
      `UPDATE branches SET name = COALESCE($3,name), city = COALESCE($4,city)
       WHERE id = $1 AND owner_id = $2 RETURNING id, name, city`,
      [req.params.id, req.owner.id, name ? name.trim() : null, city != null ? city.trim() : null]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'الفرع غير موجود' });
    res.json({ ok: true, branch: r.rows[0] });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});
router.delete('/my/branches/:id', ownerAuth, async (req, res) => {
  try {
    const r = await query('DELETE FROM branches WHERE id = $1 AND owner_id = $2 RETURNING id',
      [req.params.id, req.owner.id]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'الفرع غير موجود' });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══════════ الموظفون ═══════════
router.get('/my/employees', ownerAuth, async (req, res) => {
  try {
    const r = await query(`
      SELECT e.id, e.name, e.role, e.phone, e.salary_iqd, e.active, b.name AS branch_name, e.branch_id
      FROM employees e LEFT JOIN branches b ON b.id = e.branch_id
      WHERE e.owner_id = $1 ORDER BY e.id DESC`, [req.owner.id]);
    res.json({ ok: true, employees: r.rows });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});
router.post('/my/employees', ownerAuth, async (req, res) => {
  try {
    const { name, role, phone, salary_iqd, branch_id } = req.body || {};
    if (!name || !name.trim()) return res.status(400).json({ error: 'أدخل اسم الموظف' });
    const r = await query(`
      INSERT INTO employees (owner_id, branch_id, name, role, phone, salary_iqd)
      VALUES ($1,$2,$3,$4,$5,$6) RETURNING id`,
      [req.owner.id, branch_id || null, name.trim(), (role || 'موظف').trim(),
       (phone || '').trim() || null, parseInt(salary_iqd, 10) || 0]);
    res.json({ ok: true, id: r.rows[0].id });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});
router.patch('/my/employees/:id', ownerAuth, async (req, res) => {
  try {
    const { name, role, phone, salary_iqd, active } = req.body || {};
    const r = await query(`
      UPDATE employees SET name=COALESCE($3,name), role=COALESCE($4,role),
        phone=COALESCE($5,phone), salary_iqd=COALESCE($6,salary_iqd), active=COALESCE($7,active)
      WHERE id=$1 AND owner_id=$2 RETURNING id`,
      [req.params.id, req.owner.id, name ? name.trim() : null, role ? role.trim() : null,
       phone != null ? phone.trim() : null, salary_iqd != null ? parseInt(salary_iqd, 10) : null,
       typeof active === 'boolean' ? active : null]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});
router.delete('/my/employees/:id', ownerAuth, async (req, res) => {
  try {
    const r = await query('DELETE FROM employees WHERE id=$1 AND owner_id=$2 RETURNING id',
      [req.params.id, req.owner.id]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══════════ الخدمات / الأسعار ═══════════
router.get('/my/services', ownerAuth, async (req, res) => {
  try {
    const r = await query(`
      SELECT s.id, s.name, s.price_iqd, s.duration_min, s.active, b.name AS branch_name, s.branch_id
      FROM services s LEFT JOIN branches b ON b.id = s.branch_id
      WHERE s.owner_id = $1 ORDER BY s.id DESC`, [req.owner.id]);
    res.json({ ok: true, services: r.rows });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});
router.post('/my/services', ownerAuth, async (req, res) => {
  try {
    const { name, price_iqd, duration_min, branch_id } = req.body || {};
    if (!name || !name.trim()) return res.status(400).json({ error: 'أدخل اسم الخدمة' });
    const r = await query(`
      INSERT INTO services (owner_id, branch_id, name, price_iqd, duration_min)
      VALUES ($1,$2,$3,$4,$5) RETURNING id`,
      [req.owner.id, branch_id || null, name.trim(), parseInt(price_iqd, 10) || 0, parseInt(duration_min, 10) || 15]);
    res.json({ ok: true, id: r.rows[0].id });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});
router.patch('/my/services/:id', ownerAuth, async (req, res) => {
  try {
    const { name, price_iqd, duration_min, active } = req.body || {};
    const r = await query(`
      UPDATE services SET name=COALESCE($3,name), price_iqd=COALESCE($4,price_iqd),
        duration_min=COALESCE($5,duration_min), active=COALESCE($6,active)
      WHERE id=$1 AND owner_id=$2 RETURNING id`,
      [req.params.id, req.owner.id, name ? name.trim() : null,
       price_iqd != null ? parseInt(price_iqd, 10) : null,
       duration_min != null ? parseInt(duration_min, 10) : null,
       typeof active === 'boolean' ? active : null]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});
router.delete('/my/services/:id', ownerAuth, async (req, res) => {
  try {
    const r = await query('DELETE FROM services WHERE id=$1 AND owner_id=$2 RETURNING id',
      [req.params.id, req.owner.id]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

module.exports = router;
