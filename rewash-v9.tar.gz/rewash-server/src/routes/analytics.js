// src/routes/analytics.js — مقارنة الفترات + تنبيهات الاشتراكات
'use strict';
const express = require('express');
const { query } = require('../db/pool');
const { adminAuth, ownerAuth } = require('../middleware/auth');

const router = express.Router();

// نطاق الفترة الحالية والسابقة (بالأيام)
function rangeDays(period) {
  return period === 'today' ? 1 : period === 'week' ? 7 : period === 'year' ? 365 : 30;
}
function periodLabel(period) {
  return period === 'today' ? 'اليوم' : period === 'week' ? 'آخر أسبوع'
    : period === 'year' ? 'آخر سنة' : 'آخر شهر';
}
function growth(cur, prev) {
  cur = Number(cur || 0); prev = Number(prev || 0);
  if (prev === 0) return cur > 0 ? 100 : 0;
  return Math.round(((cur - prev) / prev) * 1000) / 10; // نسبة بخانة عشرية
}

// يحسب مقارنة الفترة الحالية بالسابقة
async function buildCompare(period, ownerFilter) {
  const d = rangeDays(period);
  const wOwner = ownerFilter ? 'AND b.owner_id = $1' : '';
  const params = ownerFilter ? [ownerFilter] : [];
  // الحالية: آخر d يوم. السابقة: الـ d يوم اللي قبلها
  const cur = await query(`
    SELECT COALESCE(SUM(s.total_iqd),0) AS revenue,
      COALESCE(SUM(s.invoice_count),0) AS invoices,
      COALESCE(SUM(s.cars_count),0) AS cars
    FROM sales_summary s JOIN branches b ON b.id = s.branch_id
    WHERE s.business_day > CURRENT_DATE - $${params.length + 1}::int ${wOwner}`,
    params.concat([d]));
  const prev = await query(`
    SELECT COALESCE(SUM(s.total_iqd),0) AS revenue,
      COALESCE(SUM(s.invoice_count),0) AS invoices,
      COALESCE(SUM(s.cars_count),0) AS cars
    FROM sales_summary s JOIN branches b ON b.id = s.branch_id
    WHERE s.business_day > CURRENT_DATE - ($${params.length + 1}::int * 2)
      AND s.business_day <= CURRENT_DATE - $${params.length + 1}::int ${wOwner}`,
    params.concat([d]));
  const c = cur.rows[0], p = prev.rows[0];
  return {
    period, periodLabel: periodLabel(period),
    current: c, previous: p,
    growth: {
      revenue: growth(c.revenue, p.revenue),
      invoices: growth(c.invoices, p.invoices),
      cars: growth(c.cars, p.cars)
    }
  };
}

router.get('/admin/compare', adminAuth, async (req, res) => {
  try { res.json({ ok: true, ...(await buildCompare(req.query.period || 'month', null)) }); }
  catch (e) { console.error('[admin compare]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});
router.get('/my/compare', ownerAuth, async (req, res) => {
  try { res.json({ ok: true, ...(await buildCompare(req.query.period || 'month', req.owner.id)) }); }
  catch (e) { console.error('[my compare]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══ تنبيهات: اشتراكات المالكين (المطوّر) ═══
router.get('/admin/alerts', adminAuth, async (req, res) => {
  try {
    const days = parseInt(req.query.days, 10) || 7;
    // آخر اشتراك لكل مالك + حالته
    const r = await query(`
      WITH latest AS (
        SELECT DISTINCT ON (owner_id) owner_id, plan, amount_iqd, end_date
        FROM owner_subscriptions ORDER BY owner_id, end_date DESC
      )
      SELECT o.id AS owner_id, o.name AS owner_name, o.phone,
        l.end_date, l.plan,
        (l.end_date - CURRENT_DATE) AS days_left,
        CASE WHEN l.end_date IS NULL THEN 'none'
             WHEN l.end_date < CURRENT_DATE THEN 'expired'
             WHEN l.end_date <= CURRENT_DATE + $1::int THEN 'soon'
             ELSE 'ok' END AS state
      FROM owners o LEFT JOIN latest l ON l.owner_id = o.id
      WHERE l.end_date IS NULL OR l.end_date <= CURRENT_DATE + $1::int
      ORDER BY l.end_date NULLS FIRST`, [days]);
    res.json({ ok: true, alerts: r.rows });
  } catch (e) { console.error('[admin alerts]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══ تنبيهات: عضويات الزباين + اشتراك المالك نفسه ═══
router.get('/my/alerts', ownerAuth, async (req, res) => {
  try {
    const days = parseInt(req.query.days, 10) || 7;
    // عضويات الزباين القريبة من الانتهاء / المنتهية
    const mem = await query(`
      SELECT id, customer_name, customer_phone, end_date,
        (end_date - CURRENT_DATE) AS days_left,
        CASE WHEN end_date < CURRENT_DATE THEN 'expired' ELSE 'soon' END AS state
      FROM customer_memberships
      WHERE owner_id = $1 AND end_date IS NOT NULL
        AND end_date <= CURRENT_DATE + $2::int
      ORDER BY end_date LIMIT 100`, [req.owner.id, days]);
    // اشتراك المالك بالنظام
    const sub = await query(`
      SELECT end_date, (end_date - CURRENT_DATE) AS days_left,
        (end_date >= CURRENT_DATE) AS active
      FROM owner_subscriptions WHERE owner_id = $1
      ORDER BY end_date DESC LIMIT 1`, [req.owner.id]);
    res.json({ ok: true, memberships: mem.rows, subscription: sub.rows[0] || null });
  } catch (e) { console.error('[my alerts]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});

module.exports = router;
