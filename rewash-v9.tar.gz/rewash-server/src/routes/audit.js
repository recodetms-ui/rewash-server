// src/routes/audit.js — تدقيق التقارير + المصاريف + صافي الربح/الخسارة
'use strict';
const express = require('express');
const { query } = require('../db/pool');
const { adminAuth, ownerAuth } = require('../middleware/auth');

const router = express.Router();

function periodClause(period, col = 's.business_day') {
  if (period === 'today') return `${col} = CURRENT_DATE`;
  if (period === 'week') return `${col} > now() - interval '7 days'`;
  if (period === 'year') return `${col} > now() - interval '365 days'`;
  return `${col} > now() - interval '30 days'`;
}
function periodDays(period) { return period === 'today' ? 1 : period === 'week' ? 7 : period === 'year' ? 365 : 30; }
function periodLabel(period) {
  return period === 'today' ? 'اليوم' : period === 'week' ? 'آخر أسبوع'
    : period === 'year' ? 'آخر سنة' : 'آخر شهر';
}

// بناء تقرير تدقيق كامل لمجموعة فروع (يُستخدم للمطوّر وللمالك)
async function buildAudit(period, ownerFilter) {
  const pc = periodClause(period);
  const ec = periodClause(period, 'e.expense_day');
  const days = periodDays(period);
  const wOwner = ownerFilter ? 'AND b.owner_id = $1' : '';
  const params = ownerFilter ? [ownerFilter] : [];

  // تفصيل يومي لكل فرع
  const daily = await query(`
    SELECT s.business_day, b.name AS branch_name, b.id AS branch_id,
      s.total_iqd, s.invoice_count, s.cars_count
    FROM sales_summary s JOIN branches b ON b.id = s.branch_id
    WHERE ${pc} ${wOwner}
    ORDER BY s.business_day DESC, b.name`, params);

  // مقارنة الفروع
  const byBranch = await query(`
    SELECT b.id AS branch_id, b.name AS branch_name,
      COALESCE(SUM(s.total_iqd),0) AS revenue,
      COALESCE(SUM(s.invoice_count),0) AS invoices,
      COALESCE(SUM(s.cars_count),0) AS cars,
      COUNT(DISTINCT s.business_day) AS active_days
    FROM branches b
    LEFT JOIN sales_summary s ON s.branch_id = b.id AND ${pc}
    WHERE 1=1 ${wOwner}
    GROUP BY b.id ORDER BY revenue DESC`, params);

  // أيام بدون مبيعات: لكل فرع، الأيام ضمن الفترة بدون سجل
  const zero = await query(`
    WITH cal AS (
      SELECT generate_series(CURRENT_DATE - ($${params.length+1}::int - 1), CURRENT_DATE, interval '1 day')::date AS d
    ),
    brs AS (SELECT b.id, b.name FROM branches b WHERE 1=1 ${wOwner})
    SELECT br.name AS branch_name, cal.d AS day
    FROM brs br CROSS JOIN cal
    LEFT JOIN sales_summary s ON s.branch_id = br.id AND s.business_day = cal.d
    WHERE s.id IS NULL
    ORDER BY br.name, cal.d DESC
    LIMIT 60`, params.concat([days]));

  // المصاريف ضمن الفترة
  const exp = await query(`
    SELECT COALESCE(SUM(e.amount_iqd),0) AS total_expenses
    FROM expenses e WHERE ${ec} ${ownerFilter ? 'AND e.owner_id = $1' : ''}`, params);

  // رواتب الموظفين النشطين (شهرية) — توزّع حسب الفترة
  const sal = await query(`
    SELECT COALESCE(SUM(salary_iqd),0) AS monthly_salaries
    FROM employees WHERE active = true ${ownerFilter ? 'AND owner_id = $1' : ''}`, params);
  const monthlySal = Number(sal.rows[0].monthly_salaries || 0);
  const salFactor = period === 'today' ? (1 / 30) : period === 'week' ? (7 / 30)
    : period === 'year' ? 12 : 1;
  const salaries = Math.round(monthlySal * salFactor);

  const revenue = byBranch.rows.reduce((a, r) => a + Number(r.revenue || 0), 0);
  const expenses = Number(exp.rows[0].total_expenses || 0);

  // مقارنة الفترة السابقة المماثلة
  const prevMap = { today: [1, 1], week: [14, 7], month: [60, 30], year: [730, 365] };
  const [from, to] = prevMap[period] || [60, 30];
  const prevQ = await query(`
    SELECT COALESCE(SUM(s.total_iqd),0) AS prev_revenue
    FROM sales_summary s JOIN branches b ON b.id = s.branch_id
    WHERE s.business_day > now() - ($${params.length + 1}::int || ' days')::interval
      AND s.business_day <= now() - ($${params.length + 2}::int || ' days')::interval
      ${wOwner}`, params.concat([from, to]));
  const prevRevenue = Number(prevQ.rows[0].prev_revenue || 0);
  const growthPct = prevRevenue > 0 ? Math.round(((revenue - prevRevenue) / prevRevenue) * 100)
    : (revenue > 0 ? 100 : 0);

  // ترتيب الفروع: الأفضل والأسوأ
  const ranked = byBranch.rows.filter(b => Number(b.revenue) > 0);
  const best = ranked.length ? ranked[0] : null;
  const worst = ranked.length > 1 ? ranked[ranked.length - 1] : null;

  return {
    period, periodLabel: periodLabel(period),
    daily: daily.rows, byBranch: byBranch.rows, zeroDays: zero.rows,
    ranking: { best, worst, count: byBranch.rows.length },
    comparison: { prevRevenue, growthPct },
    finance: { revenue, expenses, salaries, net: revenue - expenses - salaries }
  };
}

// ═══ تدقيق المطوّر (كل الفروع) ═══
router.get('/admin/audit', adminAuth, async (req, res) => {
  try { res.json({ ok: true, ...(await buildAudit(req.query.period || 'month', null)) }); }
  catch (e) { console.error('[admin audit]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══ تدقيق المالك (فروعه) ═══
router.get('/my/audit', ownerAuth, async (req, res) => {
  try { res.json({ ok: true, ...(await buildAudit(req.query.period || 'month', req.owner.id)) }); }
  catch (e) { console.error('[my audit]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══ المصاريف: قائمة (المالك) ═══
router.get('/my/expenses', ownerAuth, async (req, res) => {
  try {
    const r = await query(`
      SELECT e.id, e.category, e.amount_iqd, e.expense_day, e.note, b.name AS branch_name
      FROM expenses e LEFT JOIN branches b ON b.id = e.branch_id
      WHERE e.owner_id = $1 ORDER BY e.expense_day DESC, e.id DESC LIMIT 200`, [req.owner.id]);
    res.json({ ok: true, expenses: r.rows });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══ المصاريف: إضافة (المالك) ═══
router.post('/my/expenses', ownerAuth, async (req, res) => {
  try {
    const { category, amount_iqd, expense_day, note, branch_id } = req.body || {};
    const amt = parseInt(amount_iqd, 10);
    if (!amt || amt <= 0) return res.status(400).json({ error: 'أدخل مبلغاً صحيحاً' });
    const r = await query(`
      INSERT INTO expenses (owner_id, branch_id, category, amount_iqd, expense_day, note)
      VALUES ($1,$2,$3,$4,COALESCE($5,CURRENT_DATE),$6) RETURNING id`,
      [req.owner.id, branch_id || null, (category || 'عام').trim(), amt, expense_day || null, (note || '').trim() || null]);
    res.json({ ok: true, id: r.rows[0].id });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══ المصاريف: حذف (المالك) ═══
router.delete('/my/expenses/:id', ownerAuth, async (req, res) => {
  try {
    const r = await query('DELETE FROM expenses WHERE id = $1 AND owner_id = $2 RETURNING id',
      [req.params.id, req.owner.id]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

module.exports = router;
