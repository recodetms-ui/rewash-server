// src/routes/auto-backup.js — نسخ احتياطي تلقائي مجدول + مساراته
'use strict';
const express = require('express');
const { query } = require('../db/pool');
const { adminAuth } = require('../middleware/auth');

const router = express.Router();

const KEEP = 14;            // نحتفظ بآخر 14 لقطة
const EVERY_MS = 24 * 60 * 60 * 1000; // كل 24 ساعة

// تجميع لقطة كاملة من البيانات
async function buildSnapshot() {
  const owners = await query('SELECT id, name, phone, password_hash, active, store_name, address, notes, created_at FROM owners ORDER BY id');
  const branches = await query('SELECT id, owner_id, name, city, created_at FROM branches ORDER BY id');
  const devices = await query('SELECT id, hardware_id, branch_id, device_token, label, last_seen, app_version, created_at FROM devices ORDER BY id');
  const licenses = await query('SELECT id, hardware_id, owner_id, license_key, lic_type, store_ar, store_en, status, expires_at, created_at FROM licenses ORDER BY id');
  const sales = await query('SELECT id, device_id, branch_id, business_day, total_iqd, total_usd, invoice_count, cars_count, payload, synced_at FROM sales_summary ORDER BY id');
  // جداول اختيارية (قد لا تكون موجودة بالنسخ القديمة)
  const safe = async (sql) => { try { return (await query(sql)).rows; } catch (_) { return []; } };
  const expenses = await safe('SELECT * FROM expenses ORDER BY id');
  const ownerSubs = await safe('SELECT * FROM owner_subscriptions ORDER BY id');
  const custMems = await safe('SELECT * FROM customer_memberships ORDER BY id');
  const employees = await safe('SELECT * FROM employees ORDER BY id');
  const services = await safe('SELECT * FROM services ORDER BY id');

  const data = {
    _meta: { app: 'rewash-server', version: 2, exported_at: new Date().toISOString() },
    owners: owners.rows, branches: branches.rows, devices: devices.rows,
    licenses: licenses.rows, sales_summary: sales.rows,
    expenses, owner_subscriptions: ownerSubs, customer_memberships: custMems,
    employees, services
  };
  const counts = {
    owners: owners.rowCount, branches: branches.rowCount, devices: devices.rowCount,
    sales: sales.rowCount, expenses: expenses.length, memberships: custMems.length,
    employees: employees.length, services: services.length
  };
  return { data, counts };
}

// أخذ لقطة وحفظها + حذف القديمة
async function takeSnapshot(label = 'تلقائي') {
  const { data, counts } = await buildSnapshot();
  const json = JSON.stringify(data);
  const size = Buffer.byteLength(json, 'utf8');
  const r = await query(
    `INSERT INTO auto_backups (label, size_bytes, counts, data) VALUES ($1,$2,$3,$4) RETURNING id, created_at`,
    [label, size, JSON.stringify(counts), json]);
  // احذف ما زاد عن KEEP
  await query(`DELETE FROM auto_backups WHERE id NOT IN
    (SELECT id FROM auto_backups ORDER BY created_at DESC LIMIT $1)`, [KEEP]);
  return { id: r.rows[0].id, created_at: r.rows[0].created_at, size, counts };
}

// المجدول: يأخذ لقطة عند الإقلاع (إذا ماكو لقطة اليوم) ثم كل 24 ساعة
function startScheduler() {
  const run = async () => {
    try {
      const last = await query(`SELECT created_at FROM auto_backups
        WHERE created_at > now() - interval '20 hours' ORDER BY created_at DESC LIMIT 1`);
      if (last.rowCount === 0) {
        const s = await takeSnapshot('تلقائي');
        console.log(`💾 نسخة احتياطية تلقائية #${s.id} (${(s.size/1024).toFixed(0)}KB)`);
      }
    } catch (e) { console.error('[auto-backup]', e.message); }
  };
  setTimeout(run, 15000);          // بعد 15 ثانية من الإقلاع
  setInterval(run, EVERY_MS);      // ثم يومياً
}

// ═══════════ المسارات (المطوّر) ═══════════
router.get('/admin/backups', adminAuth, async (req, res) => {
  try {
    const r = await query(`SELECT id, label, size_bytes, counts, created_at
      FROM auto_backups ORDER BY created_at DESC LIMIT 50`);
    res.json({ ok: true, backups: r.rows, keep: KEEP });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// تشغيل نسخة الآن يدوياً
router.post('/admin/backups/run', adminAuth, async (req, res) => {
  try { const s = await takeSnapshot('يدوي'); res.json({ ok: true, ...s }); }
  catch (e) { console.error('[backup run]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});

// تنزيل لقطة كاملة
router.get('/admin/backups/:id', adminAuth, async (req, res) => {
  try {
    const r = await query('SELECT data, created_at FROM auto_backups WHERE id = $1', [req.params.id]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true, backup: r.rows[0].data, created_at: r.rows[0].created_at });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

router.delete('/admin/backups/:id', adminAuth, async (req, res) => {
  try {
    const r = await query('DELETE FROM auto_backups WHERE id = $1 RETURNING id', [req.params.id]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

module.exports = { router, startScheduler, takeSnapshot };
