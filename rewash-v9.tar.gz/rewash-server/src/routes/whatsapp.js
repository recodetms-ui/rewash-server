// src/routes/whatsapp.js — واتساب التلقائي (WhatsApp Cloud API) + الإعدادات
'use strict';
const express = require('express');
const { query } = require('../db/pool');
const { adminAuth } = require('../middleware/auth');

const router = express.Router();

// قراءة إعداد
async function getSetting(key) {
  try { const r = await query('SELECT value FROM app_settings WHERE key=$1', [key]); return r.rows[0] ? r.rows[0].value : null; }
  catch (_) { return null; }
}
async function setSetting(key, value) {
  await query(`INSERT INTO app_settings (key,value,updated_at) VALUES ($1,$2,now())
    ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value, updated_at=now()`, [key, value]);
}

// إرسال رسالة عبر WhatsApp Cloud API
// يحتاج إعدادات: wa_token (توكن دائم), wa_phone_id (معرّف رقم المرسِل)
async function sendWhatsAppText(toPhone, text) {
  const token = await getSetting('wa_token');
  const phoneId = await getSetting('wa_phone_id');
  if (!token || !phoneId) return { ok: false, error: 'واتساب غير مُعد (التوكن أو معرّف الرقم مفقود)' };
  const to = String(toPhone || '').replace(/[^0-9]/g, '');
  if (!to) return { ok: false, error: 'رقم المستلم غير صالح' };
  try {
    const resp = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, {
      method: 'POST',
      headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' },
      body: JSON.stringify({ messaging_product: 'whatsapp', to, type: 'text', text: { body: text } })
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) return { ok: false, error: (data.error && data.error.message) || ('HTTP ' + resp.status) };
    return { ok: true, id: data.messages && data.messages[0] && data.messages[0].id };
  } catch (e) { return { ok: false, error: e.message }; }
}

// ═══════════ المسارات (المطوّر) ═══════════
// قراءة الإعدادات (التوكن مخفي جزئياً)
router.get('/admin/whatsapp/settings', adminAuth, async (req, res) => {
  try {
    const token = await getSetting('wa_token');
    const phoneId = await getSetting('wa_phone_id');
    const enabled = await getSetting('wa_enabled');
    res.json({
      ok: true,
      configured: !!(token && phoneId),
      enabled: enabled === '1',
      phone_id: phoneId || '',
      token_set: !!token,
      token_hint: token ? (token.slice(0, 6) + '••••••' + token.slice(-4)) : ''
    });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// حفظ الإعدادات
router.post('/admin/whatsapp/settings', adminAuth, async (req, res) => {
  try {
    const { token, phone_id, enabled } = req.body || {};
    if (typeof token === 'string' && token.trim()) await setSetting('wa_token', token.trim());
    if (typeof phone_id === 'string') await setSetting('wa_phone_id', phone_id.trim());
    await setSetting('wa_enabled', enabled ? '1' : '0');
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// اختبار الإرسال
router.post('/admin/whatsapp/test', adminAuth, async (req, res) => {
  try {
    const { to } = req.body || {};
    const r = await sendWhatsAppText(to, '✅ اختبار RE-WASH — واتساب يعمل بنجاح!');
    if (!r.ok) return res.status(400).json(r);
    res.json(r);
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

module.exports = { router, sendWhatsAppText, getSetting, setSetting };
