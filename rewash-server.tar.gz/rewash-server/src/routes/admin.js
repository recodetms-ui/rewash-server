// src/routes/admin.js — نقاط قراءة للوحة إدارة المطوّر (محمية بمفتاح الإدارة)
'use strict';
const express = require('express');
const { query } = require('../db/pool');
const { adminAuth } = require('../middleware/auth');

const router = express.Router();

// نظرة عامة سريعة (أعداد)
router.get('/admin/overview', adminAuth, async (req, res) => {
  try {
    const r = await query(`
      SELECT
        (SELECT COUNT(*) FROM owners)   AS owners,
        (SELECT COUNT(*) FROM branches) AS branches,
        (SELECT COUNT(*) FROM devices)  AS devices,
        (SELECT COUNT(*) FROM licenses WHERE status='active') AS active_licenses
    `);
    res.json({ ok: true, stats: r.rows[0] });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// كل المالكين
router.get('/admin/owners', adminAuth, async (req, res) => {
  try {
    const r = await query(`
      SELECT o.id, o.name, o.phone, o.active, o.created_at,
        COUNT(DISTINCT b.id) AS branches
      FROM owners o LEFT JOIN branches b ON b.owner_id = o.id
      GROUP BY o.id ORDER BY o.created_at DESC`);
    res.json({ ok: true, owners: r.rows });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// كل الأجهزة (مع الفرع والمالك وحالة الترخيص)
router.get('/admin/devices', adminAuth, async (req, res) => {
  try {
    const r = await query(`
      SELECT d.hardware_id, d.label, d.last_seen, d.app_version,
        b.name AS branch_name, b.id AS branch_id,
        o.name AS owner_name, o.id AS owner_id,
        (SELECT status FROM licenses l WHERE l.hardware_id = d.hardware_id ORDER BY updated_at DESC LIMIT 1) AS license_status
      FROM devices d
      LEFT JOIN branches b ON b.id = d.branch_id
      LEFT JOIN owners o ON o.id = b.owner_id
      ORDER BY d.created_at DESC`);
    res.json({ ok: true, devices: r.rows });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

module.exports = router;
