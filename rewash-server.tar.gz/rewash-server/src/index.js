// src/index.js — نقطة دخول خادم RE-WASH
'use strict';
require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const devices = require('./routes/devices');
const licenses = require('./routes/licenses');
const sync = require('./routes/sync');
const owners = require('./routes/owners');
const branches = require('./routes/branches');
const admin = require('./routes/admin');

const app = express();
app.set('trust proxy', 1);   // خلف Nginx/Cloudflare

// ── الأمان ──
app.use(helmet());
const allowed = (process.env.ALLOWED_ORIGINS || '').split(',').map(s => s.trim()).filter(Boolean);
app.use(cors({
  origin: (origin, cb) => {
    // اسمح للأجهزة (بدون origin) وللنطاقات المصرّح بها فقط
    if (!origin || allowed.length === 0 || allowed.includes(origin)) return cb(null, true);
    cb(new Error('CORS: نطاق غير مصرّح'));
  }
}));
app.use(express.json({ limit: '10mb' }));   // النسخ الاحتياطية قد تكون كبيرة

// ── تحديد المعدّل (حماية من الإساءة) ──
const apiLimiter = rateLimit({ windowMs: 60 * 1000, max: 120, standardHeaders: true, legacyHeaders: false });
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20 });   // أقسى على تسجيل الدخول
app.use('/api/', apiLimiter);
app.use('/api/owners/login', authLimiter);

// ── المسارات ──
app.use('/api', devices);
app.use('/api', licenses);
app.use('/api', sync);
app.use('/api', owners);
app.use('/api', branches);
app.use('/api', admin);

// لوحة التحكم PWA (ملفات ثابتة) — تُبنى لاحقاً في public/
app.use('/', express.static('public'));

// معالج أخطاء عام
app.use((err, req, res, next) => {
  console.error('[error]', err.message);
  res.status(err.message && err.message.startsWith('CORS') ? 403 : 500)
     .json({ error: err.message || 'خطأ خادم' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 RE-WASH server يعمل على المنفذ ${PORT} (${process.env.NODE_ENV || 'development'})`);
});
