-- ═══════════════════════════════════════════════════════════════
--  RE-WASH Server — مخطط قاعدة البيانات
--  PostgreSQL — يُنفّذ مرة واحدة عبر: npm run migrate
-- ═══════════════════════════════════════════════════════════════

-- ── المالكون (أصحاب المغاسل — يدخلون لوحة التحكم) ──
CREATE TABLE IF NOT EXISTS owners (
  id            BIGSERIAL PRIMARY KEY,
  name          TEXT NOT NULL,
  phone         TEXT UNIQUE NOT NULL,           -- رقم الهاتف = اسم الدخول
  password_hash TEXT NOT NULL,                  -- bcrypt
  email         TEXT,
  active        BOOLEAN NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── الفروع (كل مالك يقدر يملك عدة فروع/مغاسل) ──
CREATE TABLE IF NOT EXISTS branches (
  id          BIGSERIAL PRIMARY KEY,
  owner_id    BIGINT NOT NULL REFERENCES owners(id) ON DELETE CASCADE,
  name        TEXT NOT NULL,
  city        TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── الأجهزة (كل جهاز كاشير مسجّل، مربوط بفرع) ──
CREATE TABLE IF NOT EXISTS devices (
  id           BIGSERIAL PRIMARY KEY,
  hardware_id  TEXT UNIQUE NOT NULL,            -- HW-XXXXXXXX
  branch_id    BIGINT REFERENCES branches(id) ON DELETE SET NULL,
  device_token TEXT UNIQUE NOT NULL,            -- سر للمصادقة (مولّد عشوائياً)
  label        TEXT,                            -- اسم وصفي للجهاز
  last_seen    TIMESTAMPTZ,
  app_version  TEXT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ── التراخيص والاشتراكات ──
CREATE TABLE IF NOT EXISTS licenses (
  id            BIGSERIAL PRIMARY KEY,
  hardware_id   TEXT NOT NULL,
  owner_id      BIGINT REFERENCES owners(id) ON DELETE SET NULL,
  license_key   TEXT NOT NULL,                  -- المفتاح الموقّع الكامل
  lic_type      TEXT NOT NULL,                  -- PRO2 / BSC1 / TRL0 ...
  store_ar      TEXT,
  store_en      TEXT,
  status        TEXT NOT NULL DEFAULT 'active', -- active / suspended / expired
  expires_at    TIMESTAMPTZ,                    -- NULL = دائم
  created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_licenses_hw ON licenses(hardware_id);

-- ── المبيعات المزامنة (ملخّص يومي من كل جهاز للتقارير) ──
CREATE TABLE IF NOT EXISTS sales_summary (
  id           BIGSERIAL PRIMARY KEY,
  device_id    BIGINT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
  branch_id    BIGINT REFERENCES branches(id) ON DELETE SET NULL,
  business_day DATE NOT NULL,
  total_iqd    BIGINT NOT NULL DEFAULT 0,
  total_usd    NUMERIC(12,2) NOT NULL DEFAULT 0,
  invoice_count INTEGER NOT NULL DEFAULT 0,
  cars_count   INTEGER NOT NULL DEFAULT 0,
  payload      JSONB,                            -- تفاصيل إضافية مرنة
  synced_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (device_id, business_day)               -- يوم واحد لكل جهاز (upsert)
);
CREATE INDEX IF NOT EXISTS idx_sales_branch_day ON sales_summary(branch_id, business_day);

-- ── النسخ الاحتياطية السحابية (آخر نسخة من قاعدة بيانات كل جهاز) ──
CREATE TABLE IF NOT EXISTS backups (
  id          BIGSERIAL PRIMARY KEY,
  device_id   BIGINT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
  size_bytes  BIGINT NOT NULL,
  checksum    TEXT NOT NULL,                     -- sha256 للتحقق
  data        JSONB NOT NULL,                    -- محتوى قاعدة البيانات
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_backups_device ON backups(device_id, created_at DESC);

-- ── سجل الأحداث (تدقيق: من فعل ماذا ومتى) ──
CREATE TABLE IF NOT EXISTS audit_log (
  id          BIGSERIAL PRIMARY KEY,
  actor       TEXT,                              -- owner:ID / device:HW / admin
  action      TEXT NOT NULL,
  detail      JSONB,
  ip          TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
