-- 002_batch3.sql — مصاريف (لحساب صافي الربح/الخسارة)
CREATE TABLE IF NOT EXISTS expenses (
  id          BIGSERIAL PRIMARY KEY,
  owner_id    BIGINT REFERENCES owners(id) ON DELETE CASCADE,
  branch_id   BIGINT REFERENCES branches(id) ON DELETE SET NULL,
  category    TEXT NOT NULL DEFAULT 'عام',
  amount_iqd  BIGINT NOT NULL DEFAULT 0,
  expense_day DATE NOT NULL DEFAULT CURRENT_DATE,
  note        TEXT,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_expenses_owner ON expenses(owner_id);
CREATE INDEX IF NOT EXISTS idx_expenses_day ON expenses(expense_day);
