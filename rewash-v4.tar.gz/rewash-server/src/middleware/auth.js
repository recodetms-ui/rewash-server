// src/middleware/auth.js — المصادقة: جهاز / مالك / مدير
'use strict';
const jwt = require('jsonwebtoken');
const { query } = require('../db/pool');

// ── مصادقة الجهاز: ترويسة x-device-token ──
async function deviceAuth(req, res, next) {
  try {
    const token = req.get('x-device-token');
    const hwId = req.get('x-hardware-id');
    if (!token || !hwId) return res.status(401).json({ error: 'بيانات الجهاز ناقصة' });
    const r = await query(
      'SELECT id, hardware_id, branch_id FROM devices WHERE device_token = $1 AND hardware_id = $2',
      [token, hwId]
    );
    if (r.rowCount === 0) return res.status(401).json({ error: 'جهاز غير مصرّح' });
    req.device = r.rows[0];
    // حدّث آخر ظهور (بدون انتظار)
    query('UPDATE devices SET last_seen = now(), app_version = $2 WHERE id = $1',
      [req.device.id, req.get('x-app-version') || null]).catch(() => {});
    next();
  } catch (e) {
    console.error('[deviceAuth]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
}

// ── مصادقة المالك: ترويسة Authorization: Bearer <jwt> ──
function ownerAuth(req, res, next) {
  try {
    const h = req.get('authorization') || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'مطلوب تسجيل دخول' });
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    if (payload.role !== 'owner') return res.status(403).json({ error: 'صلاحية غير كافية' });
    req.owner = { id: payload.sub };
    next();
  } catch (e) {
    return res.status(401).json({ error: 'جلسة منتهية أو غير صالحة' });
  }
}

// ── مصادقة المدير (المطور): ترويسة x-admin-key ──
function adminAuth(req, res, next) {
  const key = req.get('x-admin-key');
  if (!key || key !== process.env.ADMIN_API_KEY) {
    return res.status(403).json({ error: 'ممنوع' });
  }
  next();
}

module.exports = { deviceAuth, ownerAuth, adminAuth };
