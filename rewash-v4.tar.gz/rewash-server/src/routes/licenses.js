// src/routes/licenses.js — التراخيص والاشتراكات (تحقق أونلاين + تحكم عن بُعد)
'use strict';
const express = require('express');
const { query } = require('../db/pool');
const { deviceAuth, adminAuth } = require('../middleware/auth');
const { verifyLicenseSignature } = require('../utils/license');

const router = express.Router();

// تسجيل/تحديث ترخيص (المطور — بعد البيع)
router.post('/licenses', adminAuth, async (req, res) => {
  try {
    const { license_key, owner_id } = req.body || {};
    const v = verifyLicenseSignature(license_key);
    if (!v.ok) return res.status(400).json({ error: 'مفتاح غير صالح: ' + v.reason });
    const p = v.payload;
    const r = await query(
      `INSERT INTO licenses (hardware_id, owner_id, license_key, lic_type, store_ar, store_en, expires_at)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       RETURNING id, hardware_id, lic_type, status, expires_at`,
      [p.hw, owner_id || null, license_key, p.lic, p.sa || null, p.se || null, p.exp || null]
    );
    res.json({ ok: true, license: r.rows[0] });
  } catch (e) {
    console.error('[lic create]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

// تحقق أونلاين من حالة الترخيص (يستدعيه التطبيق عند توفر النت)
// يبقى التطبيق يشتغل أوفلاين بالمفتاح؛ هذا فقط يكتشف الإيقاف عن بُعد والاشتراكات
router.get('/licenses/status', deviceAuth, async (req, res) => {
  try {
    const r = await query(
      `SELECT status, lic_type, expires_at, store_ar, store_en
       FROM licenses WHERE hardware_id = $1 ORDER BY updated_at DESC LIMIT 1`,
      [req.device.hardware_id]
    );
    if (r.rowCount === 0) return res.json({ ok: true, known: false });
    const lic = r.rows[0];
    const expired = lic.expires_at && new Date(lic.expires_at) < new Date();
    res.json({
      ok: true,
      known: true,
      status: expired ? 'expired' : lic.status,
      lic_type: lic.lic_type,
      expires_at: lic.expires_at,
      active: lic.status === 'active' && !expired
    });
  } catch (e) {
    console.error('[lic status]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

// إيقاف/تفعيل ترخيص عن بُعد (المطور — مثلاً عند عدم الدفع)
router.patch('/licenses/:hardwareId', adminAuth, async (req, res) => {
  try {
    const { status, expires_at } = req.body || {};
    if (status && !['active', 'suspended', 'expired'].includes(status)) {
      return res.status(400).json({ error: 'حالة غير صحيحة' });
    }
    const r = await query(
      `UPDATE licenses SET
         status = COALESCE($2, status),
         expires_at = COALESCE($3, expires_at),
         updated_at = now()
       WHERE hardware_id = $1
       RETURNING hardware_id, status, expires_at`,
      [req.params.hardwareId.toUpperCase(), status || null, expires_at || null]
    );
    if (r.rowCount === 0) return res.status(404).json({ error: 'غير موجود' });
    res.json({ ok: true, license: r.rows[0] });
  } catch (e) {
    console.error('[lic patch]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

module.exports = router;
