// src/routes/branches.js — إدارة الفروع وربط الأجهزة بها
'use strict';
const express = require('express');
const { query } = require('../db/pool');
const { adminAuth, ownerAuth } = require('../middleware/auth');

const router = express.Router();

// إنشاء فرع تحت مالك (المطوّر)
router.post('/branches', adminAuth, async (req, res) => {
  try {
    const { owner_id, name, city } = req.body || {};
    if (!owner_id || !name) return res.status(400).json({ error: 'owner_id والاسم مطلوبان' });
    const own = await query('SELECT id FROM owners WHERE id = $1', [owner_id]);
    if (own.rowCount === 0) return res.status(404).json({ error: 'المالك غير موجود' });
    const r = await query(
      `INSERT INTO branches (owner_id, name, city) VALUES ($1,$2,$3)
       RETURNING id, owner_id, name, city`,
      [owner_id, name, city || null]
    );
    res.json({ ok: true, branch: r.rows[0] });
  } catch (e) {
    console.error('[branch create]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

// عرض كل الفروع لمالك معيّن (المطوّر) — مفيد قبل ربط الأجهزة
router.get('/branches', adminAuth, async (req, res) => {
  try {
    const { owner_id } = req.query;
    if (!owner_id) return res.status(400).json({ error: 'owner_id مطلوب' });
    const r = await query(
      `SELECT b.id, b.name, b.city,
        COUNT(d.id) AS devices
       FROM branches b LEFT JOIN devices d ON d.branch_id = b.id
       WHERE b.owner_id = $1 GROUP BY b.id ORDER BY b.name`,
      [owner_id]
    );
    res.json({ ok: true, branches: r.rows });
  } catch (e) {
    console.error('[branch list]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

// المالك يشوف فروعه (بمصادقة المالك) — للوحة التحكم
router.get('/my/branches', ownerAuth, async (req, res) => {
  try {
    const r = await query(
      `SELECT b.id, b.name, b.city,
        COUNT(DISTINCT d.id) AS devices
       FROM branches b LEFT JOIN devices d ON d.branch_id = b.id
       WHERE b.owner_id = $1 GROUP BY b.id ORDER BY b.name`,
      [req.owner.id]
    );
    res.json({ ok: true, branches: r.rows });
  } catch (e) {
    console.error('[my branches]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

// تعديل فرع (المطوّر)
router.patch('/branches/:id', adminAuth, async (req, res) => {
  try {
    const { name, city } = req.body || {};
    const r = await query(
      `UPDATE branches SET name = COALESCE($2,name), city = COALESCE($3,city)
       WHERE id = $1 RETURNING id, name, city`,
      [req.params.id, name || null, city || null]
    );
    if (r.rowCount === 0) return res.status(404).json({ error: 'الفرع غير موجود' });
    res.json({ ok: true, branch: r.rows[0] });
  } catch (e) {
    console.error('[branch patch]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

// ربط جهاز موجود بفرع (المطوّر) — الخطوة المفتاحية لتعدد الفروع
router.patch('/devices/:hardwareId/branch', adminAuth, async (req, res) => {
  try {
    const { branch_id } = req.body || {};
    if (!branch_id) return res.status(400).json({ error: 'branch_id مطلوب' });
    const b = await query('SELECT id FROM branches WHERE id = $1', [branch_id]);
    if (b.rowCount === 0) return res.status(404).json({ error: 'الفرع غير موجود' });
    const r = await query(
      `UPDATE devices SET branch_id = $2 WHERE hardware_id = $1
       RETURNING hardware_id, branch_id, label`,
      [req.params.hardwareId.toUpperCase(), branch_id]
    );
    if (r.rowCount === 0) return res.status(404).json({ error: 'الجهاز غير موجود' });
    res.json({ ok: true, device: r.rows[0] });
  } catch (e) {
    console.error('[device branch]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

module.exports = router;
