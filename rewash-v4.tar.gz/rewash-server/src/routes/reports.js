// src/routes/reports.js — تقارير (مع فترة) + نسخة احتياطية/استعادة
'use strict';
const express = require('express');
const { query } = require('../db/pool');
const { adminAuth, ownerAuth } = require('../middleware/auth');

const router = express.Router();

// يحوّل الفترة إلى شرط SQL
function periodClause(period) {
  if (period === 'today') return "s.business_day = CURRENT_DATE";
  if (period === 'week') return "s.business_day > now() - interval '7 days'";
  if (period === 'year') return "s.business_day > now() - interval '365 days'";
  return "s.business_day > now() - interval '30 days'"; // month (افتراضي)
}
function periodLabel(period) {
  return period === 'today' ? 'اليوم' : period === 'week' ? 'آخر أسبوع'
    : period === 'year' ? 'آخر سنة' : 'آخر شهر';
}

// ═══════════ تقرير المطوّر (كل الفروع) ═══════════
router.get('/admin/report', adminAuth, async (req, res) => {
  try {
    const period = req.query.period || 'month';
    const pc = periodClause(period);
    const rows = await query(`
      SELECT b.name AS branch_name, b.city, o.name AS owner_name,
        COALESCE(SUM(s.total_iqd),0) AS total_iqd,
        COALESCE(SUM(s.total_usd),0) AS total_usd,
        COALESCE(SUM(s.invoice_count),0) AS invoices,
        COALESCE(SUM(s.cars_count),0) AS cars
      FROM branches b
      LEFT JOIN owners o ON o.id = b.owner_id
      LEFT JOIN sales_summary s ON s.branch_id = b.id AND ${pc}
      GROUP BY b.id, o.name ORDER BY total_iqd DESC`);
    const totals = await query(`
      SELECT COALESCE(SUM(s.total_iqd),0) AS total_iqd,
        COALESCE(SUM(s.invoice_count),0) AS invoices,
        COALESCE(SUM(s.cars_count),0) AS cars
      FROM sales_summary s WHERE ${pc}`);
    res.json({ ok: true, period, periodLabel: periodLabel(period),
      rows: rows.rows, totals: totals.rows[0] });
  } catch (e) { console.error('[admin report]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══════════ تقرير المالك (فروعه فقط) ═══════════
router.get('/my/report', ownerAuth, async (req, res) => {
  try {
    const period = req.query.period || 'month';
    const pc = periodClause(period);
    const rows = await query(`
      SELECT b.name AS branch_name, b.city,
        COALESCE(SUM(s.total_iqd),0) AS total_iqd,
        COALESCE(SUM(s.total_usd),0) AS total_usd,
        COALESCE(SUM(s.invoice_count),0) AS invoices,
        COALESCE(SUM(s.cars_count),0) AS cars
      FROM branches b
      LEFT JOIN sales_summary s ON s.branch_id = b.id AND ${pc}
      WHERE b.owner_id = $1
      GROUP BY b.id ORDER BY total_iqd DESC`, [req.owner.id]);
    const totals = await query(`
      SELECT COALESCE(SUM(s.total_iqd),0) AS total_iqd,
        COALESCE(SUM(s.invoice_count),0) AS invoices,
        COALESCE(SUM(s.cars_count),0) AS cars
      FROM sales_summary s JOIN branches b ON b.id = s.branch_id
      WHERE b.owner_id = $1 AND ${pc}`, [req.owner.id]);
    res.json({ ok: true, period, periodLabel: periodLabel(period),
      owner: req.owner.name, rows: rows.rows, totals: totals.rows[0] });
  } catch (e) { console.error('[my report]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══════════ نسخة احتياطية: تصدير كل البيانات ═══════════
router.get('/admin/backup/export', adminAuth, async (req, res) => {
  try {
    const owners = await query('SELECT id, name, phone, password_hash, active, created_at FROM owners ORDER BY id');
    const branches = await query('SELECT id, owner_id, name, city, created_at FROM branches ORDER BY id');
    const devices = await query('SELECT id, hardware_id, branch_id, device_token, label, last_seen, app_version, created_at FROM devices ORDER BY id');
    const licenses = await query('SELECT id, hardware_id, owner_id, license_key, lic_type, store_ar, store_en, status, expires_at, created_at FROM licenses ORDER BY id');
    const sales = await query('SELECT id, device_id, branch_id, business_day, total_iqd, total_usd, invoice_count, cars_count, payload, synced_at FROM sales_summary ORDER BY id');
    const backup = {
      _meta: { app: 'rewash-server', version: 1, exported_at: new Date().toISOString() },
      owners: owners.rows, branches: branches.rows, devices: devices.rows,
      licenses: licenses.rows, sales_summary: sales.rows
    };
    res.json({ ok: true, backup });
  } catch (e) { console.error('[backup export]', e.message); res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══════════ نسخة احتياطية: استعادة (دمج آمن) ═══════════
router.post('/admin/backup/restore', adminAuth, async (req, res) => {
  const b = (req.body && req.body.backup) || req.body;
  if (!b || !b._meta || b._meta.app !== 'rewash-server') {
    return res.status(400).json({ error: 'ملف النسخة الاحتياطية غير صالح' });
  }
  try {
    let restored = { owners: 0, branches: 0, devices: 0, licenses: 0, sales: 0 };
    for (const o of (b.owners || [])) {
      await query(`INSERT INTO owners (id,name,phone,password_hash,active,created_at)
        VALUES ($1,$2,$3,$4,COALESCE($5,true),COALESCE($6,now()))
        ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name, phone=EXCLUDED.phone,
        password_hash=EXCLUDED.password_hash, active=EXCLUDED.active`,
        [o.id, o.name, o.phone, o.password_hash, o.active, o.created_at]); restored.owners++;
    }
    for (const x of (b.branches || [])) {
      await query(`INSERT INTO branches (id,owner_id,name,city,created_at)
        VALUES ($1,$2,$3,$4,COALESCE($5,now()))
        ON CONFLICT (id) DO UPDATE SET owner_id=EXCLUDED.owner_id, name=EXCLUDED.name, city=EXCLUDED.city`,
        [x.id, x.owner_id, x.name, x.city, x.created_at]); restored.branches++;
    }
    for (const d of (b.devices || [])) {
      await query(`INSERT INTO devices (id,hardware_id,branch_id,device_token,label,last_seen,app_version,created_at)
        VALUES ($1,$2,$3,$4,$5,$6,$7,COALESCE($8,now()))
        ON CONFLICT (id) DO UPDATE SET hardware_id=EXCLUDED.hardware_id, branch_id=EXCLUDED.branch_id,
        label=EXCLUDED.label`,
        [d.id, d.hardware_id, d.branch_id, d.device_token, d.label, d.last_seen, d.app_version, d.created_at]); restored.devices++;
    }
    for (const l of (b.licenses || [])) {
      await query(`INSERT INTO licenses (id,hardware_id,owner_id,license_key,lic_type,store_ar,store_en,status,expires_at,created_at)
        VALUES ($1,$2,$3,$4,$5,$6,$7,COALESCE($8,'active'),$9,COALESCE($10,now()))
        ON CONFLICT (id) DO UPDATE SET status=EXCLUDED.status, owner_id=EXCLUDED.owner_id`,
        [l.id, l.hardware_id, l.owner_id, l.license_key, l.lic_type, l.store_ar, l.store_en, l.status, l.expires_at, l.created_at]); restored.licenses++;
    }
    for (const s of (b.sales_summary || [])) {
      await query(`INSERT INTO sales_summary (id,device_id,branch_id,business_day,total_iqd,total_usd,invoice_count,cars_count,payload,synced_at)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,COALESCE($10,now()))
        ON CONFLICT (id) DO NOTHING`,
        [s.id, s.device_id, s.branch_id, s.business_day, s.total_iqd, s.total_usd, s.invoice_count, s.cars_count, s.payload, s.synced_at]); restored.sales++;
    }
    // أعد ضبط التسلسلات حتى لا تتعارض المعرّفات الجديدة
    for (const t of ['owners','branches','devices','licenses','sales_summary']) {
      await query(`SELECT setval(pg_get_serial_sequence('${t}','id'), GREATEST((SELECT COALESCE(MAX(id),1) FROM ${t}),1))`);
    }
    res.json({ ok: true, restored });
  } catch (e) { console.error('[backup restore]', e.message); res.status(500).json({ error: 'فشل الاستعادة: ' + e.message }); }
});

module.exports = router;
