// src/routes/owners.js — تسجيل دخول المالك + بيانات لوحة التحكم
'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { query } = require('../db/pool');
const { ownerAuth, adminAuth } = require('../middleware/auth');

const router = express.Router();

// إنشاء حساب مالك (المطور فقط)
router.post('/owners', adminAuth, async (req, res) => {
  try {
    const { name, phone, password, email } = req.body || {};
    if (!name || !phone || !password || password.length < 6) {
      return res.status(400).json({ error: 'بيانات ناقصة (كلمة سر 6 أحرف على الأقل)' });
    }
    const hash = await bcrypt.hash(password, 10);
    const r = await query(
      `INSERT INTO owners (name, phone, password_hash, email) VALUES ($1,$2,$3,$4)
       RETURNING id, name, phone`,
      [name, phone, hash, email || null]
    );
    res.json({ ok: true, owner: r.rows[0] });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'رقم الهاتف مسجّل مسبقاً' });
    console.error('[owner create]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

// تسجيل دخول المالك → يرجّع JWT
router.post('/owners/login', async (req, res) => {
  try {
    const { phone, password } = req.body || {};
    if (!phone || !password) return res.status(400).json({ error: 'الهاتف وكلمة السر مطلوبان' });
    const r = await query('SELECT id, name, password_hash, active FROM owners WHERE phone = $1', [phone]);
    if (r.rowCount === 0) return res.status(401).json({ error: 'بيانات دخول خاطئة' });
    const o = r.rows[0];
    if (!o.active) return res.status(403).json({ error: 'الحساب موقوف' });
    const ok = await bcrypt.compare(password, o.password_hash);
    if (!ok) return res.status(401).json({ error: 'بيانات دخول خاطئة' });
    const token = jwt.sign({ sub: o.id, role: 'owner' }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN || '7d'
    });
    res.json({ ok: true, token, owner: { id: o.id, name: o.name } });
  } catch (e) {
    console.error('[owner login]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

// لوحة التحكم: ملخّص الفروع والمبيعات (آخر 30 يوم)
router.get('/dashboard', ownerAuth, async (req, res) => {
  try {
    const branches = await query(
      `SELECT b.id, b.name, b.city,
        COUNT(DISTINCT d.id) AS devices,
        COALESCE(SUM(s.total_iqd),0) AS total_iqd_30d,
        COALESCE(SUM(s.invoice_count),0) AS invoices_30d
       FROM branches b
       LEFT JOIN devices d ON d.branch_id = b.id
       LEFT JOIN sales_summary s ON s.branch_id = b.id AND s.business_day > now() - interval '30 days'
       WHERE b.owner_id = $1
       GROUP BY b.id ORDER BY b.name`,
      [req.owner.id]
    );
    const daily = await query(
      `SELECT s.business_day, SUM(s.total_iqd) AS iqd, SUM(s.invoice_count) AS invoices, SUM(s.cars_count) AS cars
       FROM sales_summary s
       JOIN branches b ON b.id = s.branch_id
       WHERE b.owner_id = $1 AND s.business_day > now() - interval '30 days'
       GROUP BY s.business_day ORDER BY s.business_day`,
      [req.owner.id]
    );
    res.json({ ok: true, branches: branches.rows, daily: daily.rows });
  } catch (e) {
    console.error('[dashboard]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

module.exports = router;
