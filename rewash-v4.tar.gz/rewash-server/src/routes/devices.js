// src/routes/devices.js — تسجيل الأجهزة وفحص الحالة
'use strict';
const express = require('express');
const crypto = require('crypto');
const { query } = require('../db/pool');
const { deviceAuth, adminAuth } = require('../middleware/auth');

const router = express.Router();

// فحص صحة الخادم (عام)
router.get('/health', (req, res) => {
  res.json({ ok: true, service: 'rewash-server', time: new Date().toISOString() });
});

// تسجيل جهاز جديد (يتم مرة واحدة — يُصدر device_token)
// يحتاج x-admin-key (المطور يسجّل أجهزة العملاء) أو يُربط لاحقاً بمالك
router.post('/devices/register', adminAuth, async (req, res) => {
  try {
    const { hardware_id, label, branch_id } = req.body || {};
    if (!hardware_id || !/^HW-[0-9A-F]{8}$/i.test(hardware_id)) {
      return res.status(400).json({ error: 'hardware_id غير صحيح' });
    }
    const token = crypto.randomBytes(32).toString('hex');
    const r = await query(
      `INSERT INTO devices (hardware_id, device_token, label, branch_id)
       VALUES ($1, $2, $3, $4)
       ON CONFLICT (hardware_id) DO UPDATE SET label = COALESCE(EXCLUDED.label, devices.label)
       RETURNING id, hardware_id, device_token`,
      [hardware_id.toUpperCase(), token, label || null, branch_id || null]
    );
    res.json({ ok: true, device: r.rows[0] });
  } catch (e) {
    console.error('[register]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

// نبضة من الجهاز (يتأكد إنه متصل ويحدّث آخر ظهور)
router.post('/devices/ping', deviceAuth, (req, res) => {
  res.json({ ok: true, time: new Date().toISOString() });
});

module.exports = router;
