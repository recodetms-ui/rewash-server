// src/routes/admin-manage.js — تعديل/حذف/استعادة كلمة سر/بحث (المطوّر فقط)
'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const { query } = require('../db/pool');
const { adminAuth } = require('../middleware/auth');

const router = express.Router();

// ═══════════════ المالكون ═══════════════

// تعديل مالك (الاسم/الهاتف)
router.patch('/owners/:id', adminAuth, async (req, res) => {
  try {
    const { name, phone } = req.body || {};
    const r = await query(
      `UPDATE owners SET name = COALESCE($2,name), phone = COALESCE($3,phone)
       WHERE id = $1 RETURNING id, name, phone`,
      [req.params.id, name || null, phone || null]
    );
    if (r.rowCount === 0) return res.status(404).json({ error: 'المالك غير موجود' });
    res.json({ ok: true, owner: r.rows[0] });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'رقم الهاتف مسجّل لمالك آخر' });
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

// استعادة/تعيين كلمة سر مالك
router.post('/owners/:id/reset-password', adminAuth, async (req, res) => {
  try {
    const { password } = req.body || {};
    if (!password || password.length < 6) {
      return res.status(400).json({ error: 'كلمة سر 6 أحرف على الأقل' });
    }
    const hash = await bcrypt.hash(password, 10);
    const r = await query(
      `UPDATE owners SET password_hash = $2 WHERE id = $1 RETURNING id, name`,
      [req.params.id, hash]
    );
    if (r.rowCount === 0) return res.status(404).json({ error: 'المالك غير موجود' });
    res.json({ ok: true, owner: r.rows[0] });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// حذف مالك (يحذف فروعه تلقائياً، وأجهزته تُفكّ من الفروع)
router.delete('/owners/:id', adminAuth, async (req, res) => {
  try {
    const r = await query('DELETE FROM owners WHERE id = $1 RETURNING id', [req.params.id]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'المالك غير موجود' });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══════════════ الفروع ═══════════════

// حذف فرع (أجهزته تُفكّ تلقائياً)
router.delete('/branches/:id', adminAuth, async (req, res) => {
  try {
    const r = await query('DELETE FROM branches WHERE id = $1 RETURNING id', [req.params.id]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'الفرع غير موجود' });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══════════════ الأجهزة ═══════════════

// تعديل جهاز: إعادة تسمية + فكّ الربط من الفرع (branch_id=null)
router.patch('/devices/:hardwareId', adminAuth, async (req, res) => {
  try {
    const { label, unlink } = req.body || {};
    const hw = req.params.hardwareId.toUpperCase();
    if (unlink === true) {
      const r = await query(
        `UPDATE devices SET label = COALESCE($2,label), branch_id = NULL
         WHERE hardware_id = $1 RETURNING hardware_id, label, branch_id`,
        [hw, label || null]
      );
      if (r.rowCount === 0) return res.status(404).json({ error: 'الجهاز غير موجود' });
      return res.json({ ok: true, device: r.rows[0] });
    }
    const r = await query(
      `UPDATE devices SET label = COALESCE($2,label)
       WHERE hardware_id = $1 RETURNING hardware_id, label, branch_id`,
      [hw, label || null]
    );
    if (r.rowCount === 0) return res.status(404).json({ error: 'الجهاز غير موجود' });
    res.json({ ok: true, device: r.rows[0] });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// حذف جهاز
router.delete('/devices/:hardwareId', adminAuth, async (req, res) => {
  try {
    const r = await query(
      'DELETE FROM devices WHERE hardware_id = $1 RETURNING hardware_id',
      [req.params.hardwareId.toUpperCase()]
    );
    if (r.rowCount === 0) return res.status(404).json({ error: 'الجهاز غير موجود' });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

// ═══════════════ التراخيص ═══════════════

// قائمة/بحث التراخيص (بالجهاز/المالك/النوع/الحالة)
router.get('/admin/licenses', adminAuth, async (req, res) => {
  try {
    const q = (req.query.q || '').trim();
    const params = [];
    let where = '';
    if (q) {
      params.push('%' + q + '%');
      where = `WHERE l.hardware_id ILIKE $1 OR l.lic_type ILIKE $1
               OR o.name ILIKE $1 OR d.label ILIKE $1
               OR l.store_ar ILIKE $1 OR l.store_en ILIKE $1`;
    }
    const r = await query(
      `SELECT l.id, l.hardware_id, l.lic_type, l.status, l.created_at, l.expires_at,
        l.store_ar, l.store_en,
        o.name AS owner_name, d.label AS device_label
       FROM licenses l
       LEFT JOIN owners o ON o.id = l.owner_id
       LEFT JOIN devices d ON d.hardware_id = l.hardware_id
       ${where}
       ORDER BY l.id DESC LIMIT 200`,
      params
    );
    res.json({ ok: true, licenses: r.rows });
  } catch (e) {
    console.error('[license search]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

// حذف ترخيص
router.delete('/licenses/:id', adminAuth, async (req, res) => {
  try {
    const r = await query('DELETE FROM licenses WHERE id = $1 RETURNING id', [req.params.id]);
    if (r.rowCount === 0) return res.status(404).json({ error: 'الترخيص غير موجود' });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: 'خطأ خادم' }); }
});

module.exports = router;
