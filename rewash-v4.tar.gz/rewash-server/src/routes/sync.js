// src/routes/sync.js — مزامنة ملخّص المبيعات + النسخ الاحتياطي السحابي
'use strict';
const express = require('express');
const crypto = require('crypto');
const { query } = require('../db/pool');
const { deviceAuth } = require('../middleware/auth');

const router = express.Router();

// رفع ملخّص يومي للمبيعات (upsert — يوم واحد لكل جهاز)
router.post('/sync/sales', deviceAuth, async (req, res) => {
  try {
    const { business_day, total_iqd, total_usd, invoice_count, cars_count, payload } = req.body || {};
    if (!business_day) return res.status(400).json({ error: 'business_day مطلوب' });
    await query(
      `INSERT INTO sales_summary (device_id, branch_id, business_day, total_iqd, total_usd, invoice_count, cars_count, payload)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       ON CONFLICT (device_id, business_day) DO UPDATE SET
         total_iqd = EXCLUDED.total_iqd, total_usd = EXCLUDED.total_usd,
         invoice_count = EXCLUDED.invoice_count, cars_count = EXCLUDED.cars_count,
         payload = EXCLUDED.payload, synced_at = now()`,
      [req.device.id, req.device.branch_id, business_day,
       Math.round(total_iqd || 0), total_usd || 0, invoice_count || 0, cars_count || 0,
       payload ? JSON.stringify(payload) : null]
    );
    res.json({ ok: true });
  } catch (e) {
    console.error('[sync sales]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

// رفع نسخة احتياطية كاملة من قاعدة بيانات الجهاز
router.post('/backup', deviceAuth, async (req, res) => {
  try {
    const { data } = req.body || {};
    if (!data || typeof data !== 'object') return res.status(400).json({ error: 'data مطلوبة' });
    const str = JSON.stringify(data);
    const checksum = crypto.createHash('sha256').update(str).digest('hex');
    await query(
      `INSERT INTO backups (device_id, size_bytes, checksum, data) VALUES ($1,$2,$3,$4)`,
      [req.device.id, Buffer.byteLength(str), checksum, str]
    );
    // احتفظ بآخر 10 نسخ فقط لكل جهاز
    await query(
      `DELETE FROM backups WHERE device_id = $1 AND id NOT IN (
         SELECT id FROM backups WHERE device_id = $1 ORDER BY created_at DESC LIMIT 10)`,
      [req.device.id]
    );
    res.json({ ok: true, checksum });
  } catch (e) {
    console.error('[backup]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

// استرجاع آخر نسخة احتياطية (للجهاز نفسه)
router.get('/backup/latest', deviceAuth, async (req, res) => {
  try {
    const r = await query(
      `SELECT data, checksum, created_at FROM backups WHERE device_id = $1 ORDER BY created_at DESC LIMIT 1`,
      [req.device.id]
    );
    if (r.rowCount === 0) return res.json({ ok: true, found: false });
    res.json({ ok: true, found: true, ...r.rows[0] });
  } catch (e) {
    console.error('[backup latest]', e.message);
    res.status(500).json({ error: 'خطأ خادم' });
  }
});

module.exports = router;
