// src/db/pool.js — اتصال PostgreSQL (pool مشترك)
'use strict';
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
});

pool.on('error', (err) => {
  console.error('[db] unexpected pool error:', err.message);
});

// مساعد استعلام مختصر
async function query(text, params) {
  return pool.query(text, params);
}

module.exports = { pool, query };
