// src/db/migrate.js — يشغّل ملفات SQL في مجلد migrations بالترتيب
'use strict';
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { pool } = require('./pool');

async function migrate() {
  const dir = path.join(__dirname, '..', '..', 'migrations');
  const files = fs.readdirSync(dir).filter(f => f.endsWith('.sql')).sort();
  console.log(`🗄️  تشغيل ${files.length} ملف ترحيل...`);
  for (const f of files) {
    const sql = fs.readFileSync(path.join(dir, f), 'utf8');
    try {
      await pool.query(sql);
      console.log('  ✓', f);
    } catch (e) {
      console.error('  ✗', f, '→', e.message);
      process.exit(1);
    }
  }
  console.log('✅ اكتمل الترحيل.');
  await pool.end();
}

migrate().catch(e => { console.error(e); process.exit(1); });
