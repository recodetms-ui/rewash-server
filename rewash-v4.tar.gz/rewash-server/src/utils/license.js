// src/utils/license.js — التحقق من توقيع التراخيص على الخادم (نفس منطق التطبيق)
'use strict';
const nacl = require('tweetnacl');
const naclUtil = require('tweetnacl-util');

const PREFIX = 'RWSH2';

function b64uToB64(s) {
  s = s.replace(/-/g, '+').replace(/_/g, '/');
  while (s.length % 4) s += '=';
  return s;
}

// يتحقق من توقيع المفتاح ويرجع الحمولة (بدون ربط بجهاز — الخادم يدير ذلك)
function verifyLicenseSignature(licenseString) {
  try {
    const pub = naclUtil.decodeBase64(process.env.LICENSE_PUBLIC_KEY);
    const parts = String(licenseString || '').trim().split('.');
    if (parts.length !== 3 || parts[0] !== PREFIX) return { ok: false, reason: 'صيغة غير صحيحة' };
    const payloadBytes = naclUtil.decodeBase64(b64uToB64(parts[1]));
    const sig = naclUtil.decodeBase64(b64uToB64(parts[2]));
    if (!nacl.sign.detached.verify(payloadBytes, sig, pub)) return { ok: false, reason: 'توقيع غير صالح' };
    const payload = JSON.parse(naclUtil.encodeUTF8(payloadBytes));
    return { ok: true, payload };
  } catch (e) {
    return { ok: false, reason: 'خطأ قراءة: ' + e.message };
  }
}

module.exports = { verifyLicenseSignature };
